<?php

class masterdata_model extends CI_Model {

    // acount

    public function role_list()
    {
        $this->db->select('*');
        $this->db->from('ms_role');
        $this->db->where('is_active', 'Y');
        $query = $this->db->get();
        return $query;
    }

    public function save_product_role($data_product_role)
    {
        $this->db->insert('ms_role_permision_product', $data_product_role);
    }

    public function get_settting_product($id)
    {
        $this->db->select('*');
        $this->db->from('ms_role_permision_product');
        $this->db->where('role_id', $id);
        $query = $this->db->get();
        return $query;
    }

    public function update_acc_product($update, $role_id)
    {
        $this->db->set($update);
        $this->db->where('role_id', $role_id);
        $this->db->update('ms_role_permision_product');
    }

    public function account_list($search, $length, $start)
    {
        $this->db->select('*');
        $this->db->from('ms_user');
        $this->db->join('ms_role', 'ms_user.user_role = ms_role.role_id');
        $this->db->where('ms_user.is_active', 'Y');
        $this->db->where('ms_user.user_name not like "System"');
        if($search != null){
            $this->db->where('user_name like "%'.$search.'%"');
        }

        $this->db->limit($length);
        $this->db->offset($start);
        $query = $this->db->get();
        return $query;
    }

    public function account_list_count($search)
    {
        $this->db->select('count(*) as total_row');
        $this->db->from('ms_user');
        $this->db->join('ms_role', 'ms_user.user_role = ms_role.role_id');
        $this->db->where('ms_user.is_active', 'Y');
        $this->db->where('ms_user.user_name not like "System"');
        if($search != null){
            $this->db->where('user_name like "%'.$search.'%"');
        }
        $query = $this->db->get();
        return $query;
    }

    public function save_user($data_insert)
    {
        $this->db->insert('ms_user', $data_insert);
    }

    public function get_user_by_id($user_id)
    {
        $query = $this->db->query("select * from ms_user where user_id = '".$user_id."'");
        $result = $query->result();
        return $result;
    }

    public function get_role_id_by_permission($role_permission)
    {
        $query = $this->db->query("select role_id from ms_role_permision where role_permision = '".$role_permission."'");
        $result = $query->result();
        return $result;
    }

    public function edit_user($data_insert, $user_id_inp)
    {
        $this->db->set($data_insert);
        $this->db->where('user_id', $user_id_inp);
        $this->db->update('ms_user');
    }

    public function delete_account($id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('user_id', $id);
        $this->db->update('ms_user');
    }

    // end account
    //group
    public function save_role($data_insert)
    {
        $this->db->insert('ms_role', $data_insert);
    }

    public function update_role_permision($data_edit, $role_permission)
    {
        $this->db->set($data_edit);
        $this->db->where('role_permision', $role_permission);
        $this->db->update('ms_role_permision');
    }

    public function get_setting_permission($id){
        $query = $this->db->query("select * from ms_role a, ms_role_permision b, ms_module c where a.role_id = b.role_id and b.module_id = c.module_id and a.role_id = '".$id."';");
        $result = $query->result();
        return $result;
    }

    public function save_permision($data_insert_permision)
    {
        $this->db->insert('ms_role_permision', $data_insert_permision);
    }
    
    public function group_role()
    {
        $query = $this->db->query("select * from ms_role where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function update_role($data_update, $role_id)
    {
        $this->db->set($data_update);
        $this->db->where('role_id ', $role_id);
        $this->db->update('ms_role');
    }

    public function delete_role($role_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('role_id ', $role_id);
        $this->db->update('ms_role');
    }

    public function check_role($role_name)
    {
        $query = $this->db->query("select * from ms_role where role_name = '".$role_name."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }
    //end group
    
    //brand
    public function save_brand($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('ms_brand', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function update_brand($data_update, $brand_id)
    {
        $this->db->set($data_update);
        $this->db->where('brand_id ', $brand_id);
        $this->db->update('ms_brand');
    }

    public function delete_brand($brand_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('brand_id ', $brand_id);
        $this->db->update('ms_brand');
    }

    public function brand_list()
    {
        $query = $this->db->query("select * from ms_brand where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function brand_list_all()
    {
        $query = $this->db->query("select * from ms_brand order by brand_name asc");
        $result = $query->result();
        return $result;
    }

    public function check_product_brand($product_brand)
    {
        $query = $this->db->query("select * from ms_brand where brand_name = '".$product_brand."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }
    //end brand


    //customer
    public function customer_list()
    {
        $query = $this->db->query("select * from ms_customer where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function customer_list_all()
    {
        $query = $this->db->query("select * from ms_customer order by customer_name asc");
        $result = $query->result();
        return $result;
    }

    public function product_stats()
    {
        $query = $this->db->query("select product_status, count(*) as total from ms_product where is_active = 'Y' group by product_status");
        $result = $query->result();
        return $result;
    }

    public function get_customer_by_id($id)
    {
        $query = $this->db->query("select * from ms_customer where is_active = 'Y' and customer_id='".$id."'");
        $result = $query->result();
        return $result;
    }

    public function get_customer_code($customer_id)
    {
        $query = $this->db->query("select customer_code, customer_name from ms_customer where customer_id = '".$customer_id."'");
        $result = $query->result();
        return $result;
    }

    public function delete_customer($customer_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('customer_id ', $customer_id);
        $this->db->update('ms_customer');
    }

    public function edit_customer($data_edit, $customer_code)
    {
        $this->db->set($data_edit);
        $this->db->where('customer_code ', $customer_code);
        $this->db->update('ms_customer');
    }

    public function delete_customer_expedisi($customer_code)
    {
        $this->db->where('customer_code ', $customer_code);
        $this->db->delete('ms_customer_expedisi');
    }

    public function save_customer($data_insert)
    {
        $this->db->insert('ms_customer', $data_insert);
    }

    public function save_customer_ekspedisi($insert_exp)
    {
        $this->db->insert('ms_customer_expedisi', $insert_exp);
    }

    public function last_customer_code($customer_code)
    {
        $query = $this->db->query("select customer_code from ms_customer where customer_code like '".$customer_code."%' order by customer_id desc limit 1");
        $result = $query->result();
        return $result;
    }

    //end customer

    // ekspedisi 
    public function ekspedisi_list()
    {
        $query = $this->db->query("select * from ms_ekspedisi where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function ekspedisi_list_all()
    {
        $query = $this->db->query("select * from ms_ekspedisi order by ekspedisi_name asc");
        $result = $query->result();
        return $result;
    }

    public function get_ekspedisi_name($purchase_ekspedisi)
    {
        $query = $this->db->query("select ekspedisi_name from ms_ekspedisi where ekspedisi_id = '".$purchase_ekspedisi."'");
        $result = $query->result();
        return $result;
    }

    public function save_ekspedisi($data_insert)
    {
        $this->db->insert('ms_ekspedisi', $data_insert);
    }

    public function edit_ekspedisi($data_edit, $expedisi_id)
    {
        $this->db->set($data_edit);
        $this->db->where('ekspedisi_id', $expedisi_id);
        $this->db->update('ms_ekspedisi');
    }

    public function delete_ekspedisi($expedisi_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('ekspedisi_id ', $expedisi_id);
        $this->db->update('ms_ekspedisi');
    }
    //end ekspedisi


    //warehouse

    public function save_warehouse($data_insert)
    {
        $this->db->insert('ms_warehouse', $data_insert);
    }

    public function warehouse_list()
    {
        $query = $this->db->query("select * from ms_warehouse where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function warehouse_list_all()
    {
        $query = $this->db->query("select * from ms_warehouse order by warehouse_name asc");
        $result = $query->result();
        return $result;
    }

    public function edit_warehouse($data_edit, $warehouse_id)
    {
        $this->db->set($data_edit);
        $this->db->where('warehouse_id', $warehouse_id);
        $this->db->update('ms_warehouse');
    }

    public function delete_warehouse($warehouse_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('warehouse_id ', $warehouse_id);
        $this->db->update('ms_warehouse');
    }

    public function get_warehouse_code($warehouse_id)
    {
        $query = $this->db->query("select warehouse_code, warehouse_name from ms_warehouse where warehouse_id = '".$warehouse_id."'");
        $result = $query->result();
        return $result;
    }
    //end warehouse



    //category

    public function save_category($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('ms_category', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function category_list()
    {
        $query = $this->db->query("select * from ms_category where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function category_list_all()
    {
        $query = $this->db->query("select * from ms_category order by category_name asc");
        $result = $query->result();
        return $result;
    }

    public function edit_category($data_edit, $category_id)
    {
        $this->db->set($data_edit);
        $this->db->where('category_id', $category_id);
        $this->db->update('ms_category');
    }

    public function delete_category($category_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('category_id ', $category_id);
        $this->db->update('ms_category');
    }

    public function check_product_category($product_category)
    {
        $query = $this->db->query("select * from ms_category where category_name = '".$product_category."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }
    //end category

    //salesman
    public function save_salesman($data_insert)
    {
        $this->db->insert('ms_salesman', $data_insert);
    }

    public function salesman_list()
    {
        $query = $this->db->query("select * from ms_salesman a, ms_warehouse b where a.salesman_branch = b.warehouse_id and a.is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function salesman_list_all()
    {
        $query = $this->db->query("select * from ms_salesman a, ms_warehouse b where a.salesman_branch = b.warehouse_id order by a.salesman_name asc");
        $result = $query->result();
        return $result;
    }

    public function edit_salesman($data_edit, $salesman_id)
    {
        $this->db->set($data_edit);
        $this->db->where('salesman_id', $salesman_id);
        $this->db->update('ms_salesman');
    }

    public function delete_salesman($salesman_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('salesman_id ', $salesman_id);
        $this->db->update('ms_salesman');
    }

    public function salesman_detail($id)
    {
        $query = $this->db->query("select * from ms_salesman a, ms_warehouse b where a.salesman_branch = b.warehouse_id and a.is_active = 'Y' and salesman_id = '".$id."'");
        $result = $query->result();
        return $result;
    }
    //end warehouse


    //unit
    public function save_unit($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('ms_unit', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
        
    }

    public function unit_list()
    {
        $query = $this->db->query("select * from ms_unit where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function unit_list_all()
    {
        $query = $this->db->query("select * from ms_unit order by unit_name asc");
        $result = $query->result();
        return $result;
    }

    public function edit_unit($data_edit, $unit_id)
    {
        $this->db->set($data_edit);
        $this->db->where('unit_id', $unit_id);
        $this->db->update('ms_unit');
    }

    public function delete_unit($unit_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('unit_id ', $unit_id);
        $this->db->update('ms_unit');
    }

    public function check_product_unit($product_unit)
    {
        $query = $this->db->query("select * from ms_unit where unit_name = '".$product_unit."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    //end unit

    //supplier
    public function save_supplier($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('ms_supplier', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function get_last_supplier()
    {
        $query = $this->db->query("select supplier_code from ms_supplier order by supplier_id  desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function supplier_list()
    {
        $query = $this->db->query("select * from ms_supplier where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function supplier_list_all()
    {
        $query = $this->db->query("select * from ms_supplier order by supplier_name asc");
        $result = $query->result();
        return $result;
    }

    public function edit_supplier($data_edit, $supplier_id)
    {
        $this->db->set($data_edit);
        $this->db->where('supplier_id', $supplier_id);
        $this->db->update('ms_supplier');
    }

    public function delete_supplier($supplier_id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('supplier_id ', $supplier_id);
        $this->db->update('ms_supplier');
    }

    public function get_supplier_code($supplier_id)
    {
        $query = $this->db->query("select supplier_code, supplier_name from ms_supplier where supplier_id = '".$supplier_id."'");
        $result = $query->result();
        return $result;
    }

    public function get_master_product_supplier($dt_product_id)
    {
        $query = $this->db->query("select product_supplier_id_tag, product_supplier_tag from ms_product where product_id = '".$dt_product_id."'");
        $result = $query->result();
        return $result;
    }

    public function check_product_supplier($product_supplier)
    {
        $query = $this->db->query("select * from ms_supplier where supplier_name = '".$product_supplier."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }
    //end supplier


    //product

    public function save_product($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('ms_product', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function save_product_stock($data_insert_master_stock)
    {
        $this->db->insert('ms_product_stock', $data_insert_master_stock);
    }

    public function save_product_supplier($insert_supplier)
    {
        $this->db->insert('ms_product_supplier', $insert_supplier);
    }

    public function product_list($search, $length, $start, $supplier_filter, $category_filter, $brand_filter,$product_status_filter, $in_transit_filter)
    {
        $this->db->select('*');
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_unit', 'ms_product.product_unit = ms_unit.unit_id');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        if($search != null){
            $this->db->where('ms_product.product_name like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_code like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_supplier_name like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_key like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_desc like "%'.$search.'%"');
        }
        if($supplier_filter != null){
            $this->db->where('ms_product.product_supplier_tag like "%'.$supplier_filter.'%"');
        }
        if($category_filter != null){
            $this->db->where('ms_product.product_category like "%'.$category_filter.'%"');
        }
        if($brand_filter != null){
            $this->db->where('ms_product.product_brand like "%'.$brand_filter.'%"');
        }
        if($product_status_filter != null){
            $this->db->where('ms_product.product_status', $product_status_filter);
        }
        if($in_transit_filter != null){
            if($in_transit_filter == 1){
                $this->db->where('ms_product.product_po_status = 0');
            }else{
                $this->db->where('ms_product.product_po_status > 0');
            }
        }
        $this->db->limit($length);
        $this->db->offset($start);
        $query = $this->db->get();
        return $query;
    }

    public function product_list_count($search, $supplier_filter, $category_filter, $brand_filter, $product_status_filter, $in_transit_filter)
    {
        $this->db->select('count(*) as total_row');
         $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_unit', 'ms_product.product_unit = ms_unit.unit_id');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        if($search != null){
            $this->db->where('ms_product.product_name like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_code like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_supplier_name like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_key like "%'.$search.'%"');
            $this->db->or_where('ms_product.product_desc like "%'.$search.'%"');
        }
        if($supplier_filter != null){
            $this->db->where('ms_product.product_supplier_tag like "%'.$supplier_filter.'%"');
        }
        if($category_filter != null){
            $this->db->where('ms_product.product_category like "%'.$category_filter.'%"');
        }
        if($brand_filter != null){
            $this->db->where('ms_product.product_brand like "%'.$brand_filter.'%"');
        }
        if($product_status_filter != null){
            $this->db->where('ms_product.product_status', $product_status_filter);
        }
        if($in_transit_filter != null){
            if($in_transit_filter == 1){
                $this->db->where('ms_product.product_po_status = 0');
            }else{
                $this->db->where('ms_product.product_po_status > 0');
            }
        }
        $query = $this->db->get();
        return $query;
    }

    public function count_product()
    {
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        return $this->db->count_all_results();
    }

    function count_product_filtered()
    {
        $this->db->select('*');
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        $query = $this->db->get();
        return $query->num_rows();
    }


    public function last_product_code()
    {
        $query = $this->db->query("select product_code from ms_product order by product_id desc limit 1");
        $result = $query->result();
        return $result;
    }

    public function product_stock($id)
    {
        $query = $this->db->query("select * from ms_product_stock a, ms_warehouse b, ms_product c, ms_unit d where a.warehouse_id = b.warehouse_id and a.product_id = c.product_id and c.product_unit = d.unit_id and a.product_id = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function settingproduct($id)
    {
        $query = $this->db->query("select * from ms_product a, ms_brand b, ms_unit c, ms_category d where a.product_brand = b.brand_id and a.product_unit = c.unit_id and a.product_category = d.category_id and a.product_id  = '".$id."' and a.is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function pending_po_by_product($id)
    {
        // daftar PO yang sudah dibuat untuk produk ini tapi belum masuk Pembelian (hd_po_purchase_status masih Pending),
        // hd_po_status dipakai untuk info tambahan: sudah Bongkar Barang (Success) atau belum (Pending)
        $query = $this->db->query("select hd_po.hd_po_id, hd_po.hd_po_invoice, hd_po.hd_po_date, hd_po.hd_po_status, dt_po.dt_po_qty from dt_po join hd_po on dt_po.hd_po_id = hd_po.hd_po_id where dt_po.dt_product_id = '".$id."' and hd_po.hd_po_purchase_status = 'Pending' and hd_po.hd_po_status != 'Cancel' order by hd_po.hd_po_id asc");
        $result = $query->result();
        return $result;
    }

    public function detail_note_product($id)
    {
        $query = $this->db->query("select * from ms_product_note where product_id  = '".$id."'");
        $result = $query->result();
        return $result;
    }

    public function delete_product_note($note_id)
    {
        $this->db->where('ms_product_note_id', $note_id);
        $this->db->delete('ms_product_note');
    }

    public function get_product_by_id($product_id)
    {
        $query = $this->db->query("select * from ms_product where product_id  = '".$product_id."' and is_active = 'Y'");

        $result = $query->result();
        return $result;
    }

    public function search_item_selected($item_id)
    {
        $query = $this->db->query("select * from ms_product where product_id  = '".$item_id."' and is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function search_item_selected_details($item_id)
    {
        $query = $this->db->query("select * from ms_product join ms_brand  on ms_product.product_brand = ms_brand.brand_id JOIN ms_unit  ON ms_product.product_unit = ms_unit.unit_id JOIN ms_category  ON ms_product.product_category = ms_category.category_id WHERE ms_product.is_active = 'y' AND ms_product.product_id = '".$item_id."'");
        $result = $query->result();
        return $result;
    }

    public function edit_product($data_edit, $product_id)
    {
        $this->db->set($data_edit);
        $this->db->where('product_id', $product_id);
        $this->db->update('ms_product');
    }

    public function delete_product_supplier($product_id)
    {
        $this->db->where('product_id ', $product_id);
        $this->db->delete('ms_product_supplier');
    }

    public function delete_product($id)
    {
        $this->db->set('is_active', 'N');
        $this->db->where('product_id ', $id);
        $this->db->update('ms_product');
    }


    public function delete_filter_product($user_id)
    {
        $this->db->where('user_id ', $user_id);
        $this->db->delete('product_filter');

    }

    public function insert_filter_product($data_insert)
    {
        $this->db->insert('product_filter', $data_insert);
    }

    public function get_filter_value($user_id)
    {
        $query = $this->db->query("select * from product_filter where user_id  = '".$user_id."'");
        $result = $query->result();
        return $result;
    }
    // end product

    // search product //

    public function search_product_list($searchin_key, $unit, $category, $brand, $supplier, $status, $paket, $ppn, $sort = 'name_asc', $limit = 50, $offset = 0)
    {
        $this->db->select('*, sum(stock) as total_stock');
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_unit', 'ms_product.product_unit = ms_unit.unit_id');
        $this->db->join('ms_product_stock', 'ms_product.product_id = ms_product_stock.product_id', 'left');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        if($unit != null) {
            $this->db->where('ms_product.product_unit', $unit);
        }
        if($category != null) {
            $this->db->where('ms_product.product_category', $category);
        }
        if($brand != null) {
            $this->db->where('ms_product.product_brand', $brand);
        }
        if($supplier != null) {
            $this->db->where('ms_product.product_supplier_tag like "%'.$supplier.'%"');
        }
        if($status != null) {
            $this->db->where('ms_product.product_status', $status);
        }
        if($paket != null) {
            $this->db->where('ms_product.is_package', $paket);
        }
        if($ppn != null) {
            $this->db->where('ms_product.is_ppn', $ppn);
        }   
        if($searchin_key != null){
            $this->db->where('ms_product.product_name like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_code like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_supplier_name like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_key like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_desc like "%'.$searchin_key.'%"');
        }
        $sort = strtolower($sort);
        switch($sort) {
            case 'name_desc':
                $this->db->order_by('ms_product.product_name', 'desc');
                break;
            case 'price_asc':
                $this->db->order_by('ms_product.product_sell_price_1', 'asc');
                break;
            case 'price_desc':
                $this->db->order_by('ms_product.product_sell_price_1', 'desc');
                break;
            case 'stock_asc':
                $this->db->order_by('total_stock', 'asc');
                break;
            case 'stock_desc':
                $this->db->order_by('total_stock', 'desc');
                break;
            case 'name_asc':
            default:
                $this->db->order_by('ms_product.product_name', 'asc');
                break;
        }
        $this->db->limit($limit, $offset);
        $this->db->group_by('ms_product.product_id');
        $query = $this->db->get();
        return $query;
    }

    public function search_product_list_count($searchin_key, $unit, $category, $brand, $supplier, $status, $paket, $ppn)
    {
        $this->db->select('count(distinct ms_product.product_id) as total');
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_unit', 'ms_product.product_unit = ms_unit.unit_id');
        $this->db->join('ms_product_stock', 'ms_product.product_id = ms_product_stock.product_id', 'left');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'y');
        if($unit != null) {
            $this->db->where('ms_product.product_unit', $unit);
        }
        if($category != null) {
            $this->db->where('ms_product.product_category', $category);
        }
        if($brand != null) {
            $this->db->where('ms_product.product_brand', $brand);
        }
        if($supplier != null) {
            $this->db->where('ms_product.product_supplier_tag like "%'.$supplier.'%"');
        }
        if($status != null) {
            $this->db->where('ms_product.product_status', $status);
        }
        if($paket != null) {
            $this->db->where('ms_product.is_package', $paket);
        }
        if($ppn != null) {
            $this->db->where('ms_product.is_ppn', $ppn);
        }   
        if($searchin_key != null){
            $this->db->where('ms_product.product_name like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_code like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_supplier_name like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_key like "%'.$searchin_key.'%"');
            $this->db->or_where('ms_product.product_desc like "%'.$searchin_key.'%"');
        }
        $query = $this->db->get();
        $result = $query->result_array();
        return $result[0]['total'] ?? 0;
    }
    // end search product //


    // stock mass update excell //

    public function get_product_list_for_stock_export()
    {
        $this->db->select('ms_product.*, ms_brand.brand_name, ms_category.category_name, ms_unit.unit_name');
        $this->db->from('ms_product');
        $this->db->join('ms_brand', 'ms_product.product_brand = ms_brand.brand_id');
        $this->db->join('ms_unit', 'ms_product.product_unit = ms_unit.unit_id');
        $this->db->join('ms_category', 'ms_product.product_category = ms_category.category_id');
        $this->db->where('ms_product.is_active', 'Y');
        $this->db->order_by('ms_product.product_code', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function update_product_fields($product_id, $data_update)
    {
        $this->db->set($data_update);
        $this->db->where('product_id', $product_id);
        $this->db->update('ms_product');
    }

    public function get_all_product_stock_map()
    {
        $query = $this->db->query("select product_id, warehouse_id, stock from ms_product_stock");
        return $query->result();
    }

    public function get_product_by_code($product_code)
    {
        $query = $this->db->query("select * from ms_product where product_code = '".$this->db->escape_str($product_code)."' and is_active = 'Y' limit 1");
        return $query->result();
    }

    public function get_product_stock_row($product_id, $warehouse_id)
    {
        $query = $this->db->query("select * from ms_product_stock where product_id = '".(int)$product_id."' and warehouse_id = '".(int)$warehouse_id."' limit 1");
        return $query->result();
    }

    public function upsert_product_stock($product_id, $warehouse_id, $stock)
    {
        $existing = $this->get_product_stock_row($product_id, $warehouse_id);
        if($existing){
            $this->db->set('stock', $stock);
            $this->db->where('ms_product_stock_id', $existing[0]->ms_product_stock_id);
            $this->db->update('ms_product_stock');
        }else{
            $this->db->insert('ms_product_stock', array(
                'product_id' => $product_id,
                'warehouse_id' => $warehouse_id,
                'stock' => $stock
            ));
        }
    }

    public function save_stock_excel_history($data_insert)
    {
        $this->db->trans_start();
        $this->db->insert('stock_excel_history', $data_insert);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }

    public function update_stock_excel_history($id, $data_update)
    {
        $this->db->set($data_update);
        $this->db->where('stock_excel_history_id', $id);
        $this->db->update('stock_excel_history');
    }

    public function stock_excel_history_list($limit = 100)
    {
        $query = $this->db->query("select a.*, b.user_name from stock_excel_history a left join ms_user b on a.created_by = b.user_id order by a.created_at desc limit ".(int)$limit);
        return $query->result();
    }

    public function get_stock_excel_history_by_id($id)
    {
        $query = $this->db->query("select * from stock_excel_history where stock_excel_history_id = '".(int)$id."' limit 1");
        return $query->result();
    }
    // end stock mass update excell //


    // payment type


    public function payment_list()
    {
        $query = $this->db->query("select * from ms_payment where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    public function payment_list_all()
    {
        $query = $this->db->query("select * from ms_payment order by payment_name asc");
        $result = $query->result();
        return $result;
    }

    public function save_payment($insert)
    {
        $this->db->insert('ms_payment', $insert);
    }

    public function update_payment($update, $payment_id)
    {
        $this->db->set($update);
        $this->db->where('payment_id ', $payment_id);
        $this->db->update('ms_payment');
    }
    // end payment type

    //user 

    public function user_list()
    {
        $query = $this->db->query("select * from ms_user where is_active = 'Y'");
        $result = $query->result();
        return $result;
    }

    // end user
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Faktur Penjualan</title>

	<style>

		body{
			font-family: "sans-serif";
			font-size: 24px;
            line-height: 20px;
			margin:0;
			padding:0;
		}

		.container{
			width:1100px;
			margin:auto;
		}

		table{
			width:100%;
			border-collapse:collapse;
		}

		td,th{
			padding:3px;
		}

		.box{
			border:1px solid #000;
			padding:2px;
		}

		.table-item{
			border:1px solid #000;
		}

		.table-item th{
			border-bottom:1px solid #000;
		}

		.table-item td{
			border-right:1px dotted #000;
		}

		.table-item td:last-child{
			border-right:none;
		}

		.table-item th{
			border-right:1px solid #000;
		}

		.table-item th:last-child{
			border-right:none;
		}

		.text-right{
			text-align:right;
		}

		.text-center{
			text-align:center;
		}

		.address td{
			padding:0;
			margin:0;
			line-height:1;
		}

		.page-break{
			page-break-after:always;
		}
		.sign{
		    margin-top:-5px;
		}

	</style>
</head>

<body>

	<?php

		$items_per_page = 12;
		$chunks = array_chunk($data['detail_sales_dropship'], $items_per_page);

		$total_page = count($chunks);
		$page = 1;

		foreach($chunks as $chunk){

		?>

		<div class="container">

			<!-- HEADER -->

			<table class="header">

				<tr>
					<td width="60%">
						<table class="address">

							<?php foreach($data['header_sales_dropship'] as $header){ ?>
							<tr>
								<td colspan="2"><b><?php echo $header->customer_name; ?></b></td>
							</tr>

							<tr>
								<td colspan="2"><?php echo $header->customer_address; ?></td>
							</tr>

							<tr>
								<td colspan="2"><?php echo $header->customer_phone; ?></td>
							</tr>

							<tr>
								<td width="60%">PONTIANAK</td>
								<td><b style="font-size:18px;">Faktur Penjualan</b></td>
							</tr>
							<?php } ?>

						</table>
					</td>

					<td width="40%">

						<div class="box">

							<?php foreach($data['header_sales_dropship'] as $header){ ?>

							<?php echo date('d/m/Y', strtotime($header->hd_dropship_sales_date)); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							INVOICE <?php echo $page; ?>/<?php echo $total_page; ?>

							<br><br>

							KEPADA YTH,
							<br>

							<b><?php echo $header->hd_dropship_sales_dropship_name; ?> - <?php echo $header->hd_dropship_sales_dropship_phone; ?></b>

							<br>

							<span style="font-size:18px;"><?php echo $header->hd_dropship_sales_dropship_address; ?></span>

							<?php } ?>

						</div>

					</td>
				</tr>

				<tr>
					<td width="60%">No Faktur : <?php echo $header->hd_dropship_sales_inv; ?></td>
					<td width="40%" style="text-align:left;">
						Metode Pembayaran: <b><?php echo $header->payment_name; ?></b>

						<span style="margin-left:40px;">
							T.O.P : <b><?php echo $header->hd_dropship_sales_top; ?></b>
						</span>
					</td>
				</tr>

			</table>


			<!-- TABLE -->

			<table class="table-item">

				<thead>

					<tr>
						<th width="4%">NO</th>
						<th width="8%">QTY</th>
						<th width="10%">SKU</th>
						<th>BARANG</th>
						<th width="12%">HARGA</th>
						<th width="15%">JUMLAH</th>
					</tr>

				</thead>

				<tbody>

					<?php
						$no = 1 + (($page-1) * $items_per_page);

						foreach($chunk as $row){
						?>

						<tr>
							<td><?php echo $no++; ?></td>
							<td class="text-center"><?php echo $row->dt_dropship_sales_qty; ?> X</td>
							<td><?php echo $row->product_code; ?></td>
							<td><?php echo $row->product_name; ?></td>
							<td class="text-right"><?php echo number_format($row->dt_dropship_sales_price); ?></td>
							<td class="text-right"><?php echo number_format($row->dt_dropship_sales_total); ?></td>
						</tr>

						<?php } ?>

						<?php
							$empty = $items_per_page - count($chunk);

							for($i=0;$i<$empty;$i++){
							?>

							<tr>
								<td>&nbsp;</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>

							<?php } ?>

						</tbody>

					</table>

					<br>

					<?php if($page == $total_page){ ?>

					<!-- TOTAL -->

					<table>

						<tr>

							<td width="70%"></td>

							<td width="15%"><b>TOTAL FAKTUR</b></td>

							<td class="text-right">
								<b>Rp. <?php echo number_format($header->hd_dropship_sales_total); ?></b>
							</td>

						</tr>

					</table>


					<!-- FOOTER -->

					<table class="sign">

						<tr>

							<td width="30%" class="text-center">
								PENERIMA
								<br><br><br><br>
								(.................)
							</td>

							<td width="30%" class="text-center">
								HORMAT KAMI
								<br><br><br><br>
								(.................)
							</td>

							<td width="40%">

								<table border="1" width="100%">

									<tr>
										<td>Jumlah Colly</td>
										<td class="text-center"><?php echo $header->hd_dropship_sales_colly; ?>x</td>
									</tr>

									<tr>
										<td>Item prepared by</td>
										<td class="text-center"><?php echo $header->hd_dropship_sales_prepare; ?></td>
									</tr>

								</table>

								<br>

								KETERANGAN :
								<b style="font-size:18px;"><?php echo nl2br(htmlspecialchars($header->hd_dropship_sales_note)); ?></b>

							</td>

						</tr>

					</table>

					<?php } ?>

				</div>

				<?php if($page < $total_page){ ?>
				<div class="page-break"></div>
				<?php } ?>

				<?php $page++; } ?>

			</body>
			</html>

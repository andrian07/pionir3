<?php 
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . $this->config->item('header');
?>
</div>

<div class="container">
  <div class="page-inner">
    <div class="page-header">

    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex align-items-left">
              <div>
                <h3 class="fw-bold mb-3">Daftar Transfer Stock</h3>
              </div>
              <div class="ms-md-auto py-2 py-md-0">
                <button class="btn btn-info" id="btnreload"><span class="btn-label"><i class="fas fa-sync"></i></span> Reload</button>
                  <?php if($data['check_auth']['check_access'][0]->add == 'Y'){ ?>
                  <a href="<?php echo base_url(); ?>Transferstock/addtransferstock"><button class="btn btn-primary"><span class="btn-label"><i class="fa fa-plus"></i></span>Tambah</button></a>
                <?php }else{ ?>
                  <button class="btn btn-primary" disabled><span class="btn-label"><i class="fa fa-plus"></i></span>Tambah</button>
                <?php } ?>
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#filterModal"><i class="fas fa-search"></i> Filter</button>

                <!-- Filter Modal -->
                <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="filterModalLabel">Filter Transfer Stock</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="form-group form-inline">
                          <label class="col-md-3 col-form-label">Dari: </label>
                          <div class="col-md-12 p-0">
                            <input id="start_date" name="start_date" type="date" class="form-control">
                          </div>
                        </div>
                        <div class="form-group form-inline">
                          <label class="col-md-3 col-form-label">Sampai: </label>
                          <div class="col-md-12 p-0">
                            <input id="end_date" name="end_date" type="date" class="form-control">
                          </div>
                        </div>
                        <div class="form-group form-inline">
                          <label class="col-md-3 col-form-label">Gudang Dari: </label>
                          <div class="col-md-12 p-0">
                            <select class="form-control" id="warehouse_from_filter" name="warehouse_from_filter">
                              <option value="">-- Semua Gudang --</option>
                              <?php foreach ($data['warehouse_list'] as $row) { ?>
                                <option value="<?php echo $row->warehouse_id; ?>"><?php echo $row->warehouse_name; ?></option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group form-inline">
                          <label class="col-md-3 col-form-label">Gudang Ke: </label>
                          <div class="col-md-12 p-0">
                            <select class="form-control" id="warehouse_to_filter" name="warehouse_to_filter">
                              <option value="">-- Semua Gudang --</option>
                              <?php foreach ($data['warehouse_list'] as $row) { ?>
                                <option value="<?php echo $row->warehouse_id; ?>"><?php echo $row->warehouse_name; ?></option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="btnresetfilter"><i class="fas fa-undo"></i> Reset</button>
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><i class="fas fa-times-circle"></i> Batal</button>
                        <button type="button" id="btnsearch" class="btn btn-warning"><i class="fas fa-search"></i> Cari</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card-body">
            <div class="table-responsive">
              <table id="transferstock-list" class="display table table-striped table-hover" >
                <thead>
                  <tr>
                    <th>No Transfer</th>
                    <th>Inisial</th>
                    <th>Nama Produk</th>
                    <th>Tanggal</th>
                    <th>Satuan</th>
                    <th>Qty</th>
                    <th>Dari</th>
                    <th>Ke</th>
                    <th>Stok Akhir Dari</th>
                    <th>Stok Akhir Ke</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
    
  </div>
</div>


<?php 
require DOC_ROOT_PATH . $this->config->item('footer');
?>

<script>

  $(document).ready(function() {
    transferlist_table();
  });

  function transferlist_table(){
    $('#transferstock-list').DataTable( {
      serverSide: true,
      search: true,
      processing: true,
      ordering: false,
      retrieve: true,
      ajax: {
        url: '<?php echo base_url(); ?>Transferstock/transfer_stock_list',
        type: 'POST',
        data: function (d) {
          d.start_date_val = $('#start_date').val();
          d.end_date_val = $('#end_date').val();
          d.warehouse_from_val = $('#warehouse_from_filter').val();
          d.warehouse_to_val = $('#warehouse_to_filter').val();
        },
      },
      columns: 
      [
        {data: 0},
        {data: 1},
        {data: 2},
        {data: 3},
        {data: 4},
        {data: 5},
        {data: 6},
        {data: 7},
        {data: 8},
        {data: 9},
        {data: 10},
        {data: 11}
      ]
    });
  }

  $("#btnsearch").click(function (e) {
    e.preventDefault();

    var start_date = $("#start_date").val();
    var end_date = $("#end_date").val();

    if (start_date !== '' && end_date !== '' && start_date > end_date) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Tanggal awal tidak boleh lebih besar dari tanggal akhir',
      });
      return;
    }

    $('#transferstock-list').DataTable().ajax.reload();
    $('#filterModal').modal('hide');
  });

  $("#btnresetfilter").click(function (e) {
    e.preventDefault();
    $("#start_date").val('');
    $("#end_date").val('');
    $("#warehouse_from_filter").val('');
    $("#warehouse_to_filter").val('');
    $('#transferstock-list').DataTable().ajax.reload();
    $('#filterModal').modal('hide');
  });

  function dispatch(id)
  {
    let url = '<?php echo base_url(); ?>Transferstock/printdispatch?';
    url += 'transfer_id=' + id;
     window.open(url, '_blank');
  }

  function deletes(id)
  {
    Swal.fire({
      title: 'Konfirmasi?',
      text: "Apakah Anda Yakin Menghapus Data Transfer Stock ?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Hapus'
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          type: "POST",
          url: "<?php echo base_url(); ?>Transferstock/delete_transfer_stock",
          dataType: "json",
          data: {id:id},
          success : function(data){
            if (data.code == "200"){
              $('#transferstock-list').DataTable().ajax.reload();
              let title = 'Hapus Data';
              let message = 'Data Berhasil Di Hapus';
              let state = 'danger';
              notif_success(title, message, state);
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.msg,
              })
            }
          }
        });
      }
    })
  }
  
</script>